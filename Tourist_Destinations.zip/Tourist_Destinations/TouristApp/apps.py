from django.apps import AppConfig


class TouristappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "TouristApp"
